﻿namespace Controles
{
    partial class ucEstanciaActual
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lbltxtPrecioNoche = new Label();
            lbltxtNinos = new Label();
            lbltxtEquipajeAdicional = new Label();
            lbltxtCargoAdicional = new Label();
            lbltxtAdultos = new Label();
            lbltxtCheckin = new Label();
            lbltxtPrecioFinal = new Label();
            lbltxtTemporada = new Label();
            lbltxtMascotas = new Label();
            lbltxtCheckout = new Label();
            lbltxtParcela = new Label();
            lblParcela = new Label();
            lblCheckin = new Label();
            lblCheckout = new Label();
            lblTemporada = new Label();
            lblPrecioNoche = new Label();
            lblAdultos = new Label();
            lblNinos = new Label();
            lblMascotas = new Label();
            lblEquipajeAdicional = new Label();
            lblCargoAdicional = new Label();
            lblPrecioFinal = new Label();
            SuspendLayout();
            // 
            // lbltxtPrecioNoche
            // 
            lbltxtPrecioNoche.AutoSize = true;
            lbltxtPrecioNoche.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtPrecioNoche.Location = new Point(21, 300);
            lbltxtPrecioNoche.Name = "lbltxtPrecioNoche";
            lbltxtPrecioNoche.Size = new Size(102, 20);
            lbltxtPrecioNoche.TabIndex = 44;
            lbltxtPrecioNoche.Text = "Precio noche:";
            // 
            // lbltxtNinos
            // 
            lbltxtNinos.AutoSize = true;
            lbltxtNinos.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtNinos.Location = new Point(215, 88);
            lbltxtNinos.Name = "lbltxtNinos";
            lbltxtNinos.Size = new Size(77, 20);
            lbltxtNinos.TabIndex = 43;
            lbltxtNinos.Text = "Nº Niños:";
            // 
            // lbltxtEquipajeAdicional
            // 
            lbltxtEquipajeAdicional.AutoSize = true;
            lbltxtEquipajeAdicional.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtEquipajeAdicional.Location = new Point(217, 230);
            lbltxtEquipajeAdicional.Name = "lbltxtEquipajeAdicional";
            lbltxtEquipajeAdicional.Size = new Size(138, 20);
            lbltxtEquipajeAdicional.TabIndex = 42;
            lbltxtEquipajeAdicional.Text = "Equipaje adicional:";
            // 
            // lbltxtCargoAdicional
            // 
            lbltxtCargoAdicional.AutoSize = true;
            lbltxtCargoAdicional.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtCargoAdicional.Location = new Point(217, 300);
            lbltxtCargoAdicional.Name = "lbltxtCargoAdicional";
            lbltxtCargoAdicional.Size = new Size(120, 20);
            lbltxtCargoAdicional.TabIndex = 41;
            lbltxtCargoAdicional.Text = "Cargo adicional:";
            // 
            // lbltxtAdultos
            // 
            lbltxtAdultos.AutoSize = true;
            lbltxtAdultos.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtAdultos.Location = new Point(217, 23);
            lbltxtAdultos.Name = "lbltxtAdultos";
            lbltxtAdultos.Size = new Size(91, 20);
            lbltxtAdultos.TabIndex = 40;
            lbltxtAdultos.Text = "Nº Adultos:";
            // 
            // lbltxtCheckin
            // 
            lbltxtCheckin.AutoSize = true;
            lbltxtCheckin.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtCheckin.Location = new Point(19, 88);
            lbltxtCheckin.Name = "lbltxtCheckin";
            lbltxtCheckin.Size = new Size(64, 20);
            lbltxtCheckin.TabIndex = 39;
            lbltxtCheckin.Text = "Chek in:";
            // 
            // lbltxtPrecioFinal
            // 
            lbltxtPrecioFinal.AutoSize = true;
            lbltxtPrecioFinal.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtPrecioFinal.Location = new Point(124, 349);
            lbltxtPrecioFinal.Name = "lbltxtPrecioFinal";
            lbltxtPrecioFinal.Size = new Size(91, 20);
            lbltxtPrecioFinal.TabIndex = 38;
            lbltxtPrecioFinal.Text = "Precio final:";
            // 
            // lbltxtTemporada
            // 
            lbltxtTemporada.AutoSize = true;
            lbltxtTemporada.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtTemporada.Location = new Point(21, 230);
            lbltxtTemporada.Name = "lbltxtTemporada";
            lbltxtTemporada.Size = new Size(92, 20);
            lbltxtTemporada.TabIndex = 37;
            lbltxtTemporada.Text = "Temporada:";
            // 
            // lbltxtMascotas
            // 
            lbltxtMascotas.AutoSize = true;
            lbltxtMascotas.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtMascotas.Location = new Point(217, 157);
            lbltxtMascotas.Name = "lbltxtMascotas";
            lbltxtMascotas.Size = new Size(102, 20);
            lbltxtMascotas.TabIndex = 36;
            lbltxtMascotas.Text = "Nº Mascotas:";
            // 
            // lbltxtCheckout
            // 
            lbltxtCheckout.AutoSize = true;
            lbltxtCheckout.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtCheckout.Location = new Point(21, 157);
            lbltxtCheckout.Name = "lbltxtCheckout";
            lbltxtCheckout.Size = new Size(82, 20);
            lbltxtCheckout.TabIndex = 35;
            lbltxtCheckout.Text = "Check out:";
            // 
            // lbltxtParcela
            // 
            lbltxtParcela.AutoSize = true;
            lbltxtParcela.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtParcela.Location = new Point(19, 23);
            lbltxtParcela.Name = "lbltxtParcela";
            lbltxtParcela.Size = new Size(63, 20);
            lbltxtParcela.TabIndex = 34;
            lbltxtParcela.Text = "Parcela:";
            // 
            // lblParcela
            // 
            lblParcela.AutoSize = true;
            lblParcela.Location = new Point(84, 23);
            lblParcela.Name = "lblParcela";
            lblParcela.Size = new Size(50, 20);
            lblParcela.TabIndex = 45;
            lblParcela.Text = "label1";
            // 
            // lblCheckin
            // 
            lblCheckin.AutoSize = true;
            lblCheckin.Location = new Point(85, 88);
            lblCheckin.Name = "lblCheckin";
            lblCheckin.Size = new Size(50, 20);
            lblCheckin.TabIndex = 46;
            lblCheckin.Text = "label2";
            // 
            // lblCheckout
            // 
            lblCheckout.AutoSize = true;
            lblCheckout.Location = new Point(104, 157);
            lblCheckout.Name = "lblCheckout";
            lblCheckout.Size = new Size(50, 20);
            lblCheckout.TabIndex = 47;
            lblCheckout.Text = "label3";
            // 
            // lblTemporada
            // 
            lblTemporada.AutoSize = true;
            lblTemporada.Location = new Point(115, 230);
            lblTemporada.Name = "lblTemporada";
            lblTemporada.Size = new Size(50, 20);
            lblTemporada.TabIndex = 48;
            lblTemporada.Text = "label4";
            // 
            // lblPrecioNoche
            // 
            lblPrecioNoche.AutoSize = true;
            lblPrecioNoche.Location = new Point(124, 300);
            lblPrecioNoche.Name = "lblPrecioNoche";
            lblPrecioNoche.Size = new Size(50, 20);
            lblPrecioNoche.TabIndex = 49;
            lblPrecioNoche.Text = "label5";
            // 
            // lblAdultos
            // 
            lblAdultos.AutoSize = true;
            lblAdultos.Location = new Point(307, 23);
            lblAdultos.Name = "lblAdultos";
            lblAdultos.Size = new Size(50, 20);
            lblAdultos.TabIndex = 50;
            lblAdultos.Text = "label6";
            // 
            // lblNinos
            // 
            lblNinos.AutoSize = true;
            lblNinos.Location = new Point(292, 88);
            lblNinos.Name = "lblNinos";
            lblNinos.Size = new Size(50, 20);
            lblNinos.TabIndex = 51;
            lblNinos.Text = "label7";
            // 
            // lblMascotas
            // 
            lblMascotas.AutoSize = true;
            lblMascotas.Location = new Point(318, 157);
            lblMascotas.Name = "lblMascotas";
            lblMascotas.Size = new Size(50, 20);
            lblMascotas.TabIndex = 52;
            lblMascotas.Text = "label8";
            // 
            // lblEquipajeAdicional
            // 
            lblEquipajeAdicional.AutoSize = true;
            lblEquipajeAdicional.Location = new Point(358, 230);
            lblEquipajeAdicional.Name = "lblEquipajeAdicional";
            lblEquipajeAdicional.Size = new Size(50, 20);
            lblEquipajeAdicional.TabIndex = 53;
            lblEquipajeAdicional.Text = "label9";
            // 
            // lblCargoAdicional
            // 
            lblCargoAdicional.AutoSize = true;
            lblCargoAdicional.Location = new Point(340, 300);
            lblCargoAdicional.Name = "lblCargoAdicional";
            lblCargoAdicional.Size = new Size(58, 20);
            lblCargoAdicional.TabIndex = 54;
            lblCargoAdicional.Text = "label10";
            // 
            // lblPrecioFinal
            // 
            lblPrecioFinal.AutoSize = true;
            lblPrecioFinal.Location = new Point(216, 349);
            lblPrecioFinal.Name = "lblPrecioFinal";
            lblPrecioFinal.Size = new Size(50, 20);
            lblPrecioFinal.TabIndex = 55;
            lblPrecioFinal.Text = "label5";
            // 
            // ucEstanciaActual
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblPrecioFinal);
            Controls.Add(lblCargoAdicional);
            Controls.Add(lblEquipajeAdicional);
            Controls.Add(lblMascotas);
            Controls.Add(lblNinos);
            Controls.Add(lblAdultos);
            Controls.Add(lblPrecioNoche);
            Controls.Add(lblTemporada);
            Controls.Add(lblCheckout);
            Controls.Add(lblCheckin);
            Controls.Add(lblParcela);
            Controls.Add(lbltxtPrecioNoche);
            Controls.Add(lbltxtNinos);
            Controls.Add(lbltxtEquipajeAdicional);
            Controls.Add(lbltxtCargoAdicional);
            Controls.Add(lbltxtAdultos);
            Controls.Add(lbltxtCheckin);
            Controls.Add(lbltxtPrecioFinal);
            Controls.Add(lbltxtTemporada);
            Controls.Add(lbltxtMascotas);
            Controls.Add(lbltxtCheckout);
            Controls.Add(lbltxtParcela);
            Name = "ucEstanciaActual";
            Size = new Size(421, 388);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltxtPrecioNoche;
        private Label lbltxtNinos;
        private Label lbltxtEquipajeAdicional;
        private Label lbltxtCargoAdicional;
        private Label lbltxtAdultos;
        private Label lbltxtCheckin;
        private Label lbltxtPrecioFinal;
        private Label lbltxtTemporada;
        private Label lbltxtMascotas;
        private Label lbltxtCheckout;
        private Label lbltxtParcela;
        private Label lblParcela;
        private Label lblCheckin;
        private Label lblCheckout;
        private Label lblTemporada;
        private Label lblPrecioNoche;
        private Label lblAdultos;
        private Label lblNinos;
        private Label lblMascotas;
        private Label lblEquipajeAdicional;
        private Label lblCargoAdicional;
        private Label lblPrecioFinal;
    }
}
