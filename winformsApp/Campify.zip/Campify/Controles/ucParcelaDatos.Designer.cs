﻿namespace Controles
{
    partial class ucParcelaDatos
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lbltxtId = new Label();
            lbltxtEstado = new Label();
            lbltxtTipo = new Label();
            lbltxtPrecio = new Label();
            lbltxtEntrada = new Label();
            lbltxtZonaTranquila = new Label();
            lbltxtVistas = new Label();
            lbltxtSombra = new Label();
            lbltxtBanosCerca = new Label();
            lblEntrada = new Label();
            lblZonaTranquila = new Label();
            lblVistas = new Label();
            lblSombra = new Label();
            lblBanosCerca = new Label();
            lblPrecio = new Label();
            lblTipo = new Label();
            lblEstado = new Label();
            lblId = new Label();
            SuspendLayout();
            // 
            // lbltxtId
            // 
            lbltxtId.AutoSize = true;
            lbltxtId.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtId.Location = new Point(14, 32);
            lbltxtId.Name = "lbltxtId";
            lbltxtId.Size = new Size(71, 20);
            lbltxtId.TabIndex = 0;
            lbltxtId.Text = "Número:";
            // 
            // lbltxtEstado
            // 
            lbltxtEstado.AutoSize = true;
            lbltxtEstado.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtEstado.Location = new Point(14, 169);
            lbltxtEstado.Name = "lbltxtEstado";
            lbltxtEstado.Size = new Size(60, 20);
            lbltxtEstado.TabIndex = 2;
            lbltxtEstado.Text = "Estado:";
            // 
            // lbltxtTipo
            // 
            lbltxtTipo.AutoSize = true;
            lbltxtTipo.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtTipo.Location = new Point(14, 94);
            lbltxtTipo.Name = "lbltxtTipo";
            lbltxtTipo.Size = new Size(44, 20);
            lbltxtTipo.TabIndex = 4;
            lbltxtTipo.Text = "Tipo:";
            // 
            // lbltxtPrecio
            // 
            lbltxtPrecio.AutoSize = true;
            lbltxtPrecio.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtPrecio.Location = new Point(14, 235);
            lbltxtPrecio.Name = "lbltxtPrecio";
            lbltxtPrecio.Size = new Size(56, 20);
            lbltxtPrecio.TabIndex = 9;
            lbltxtPrecio.Text = "Precio:";
            // 
            // lbltxtEntrada
            // 
            lbltxtEntrada.AutoSize = true;
            lbltxtEntrada.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtEntrada.Location = new Point(235, 235);
            lbltxtEntrada.Name = "lbltxtEntrada";
            lbltxtEntrada.Size = new Size(107, 20);
            lbltxtEntrada.TabIndex = 14;
            lbltxtEntrada.Text = "Entrada cerca:";
            // 
            // lbltxtZonaTranquila
            // 
            lbltxtZonaTranquila.AutoSize = true;
            lbltxtZonaTranquila.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtZonaTranquila.Location = new Point(235, 309);
            lbltxtZonaTranquila.Name = "lbltxtZonaTranquila";
            lbltxtZonaTranquila.Size = new Size(115, 20);
            lbltxtZonaTranquila.TabIndex = 13;
            lbltxtZonaTranquila.Text = "Zona tranquila:";
            // 
            // lbltxtVistas
            // 
            lbltxtVistas.AutoSize = true;
            lbltxtVistas.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtVistas.Location = new Point(235, 94);
            lbltxtVistas.Name = "lbltxtVistas";
            lbltxtVistas.Size = new Size(55, 20);
            lbltxtVistas.TabIndex = 12;
            lbltxtVistas.Text = "Vistas:";
            // 
            // lbltxtSombra
            // 
            lbltxtSombra.AutoSize = true;
            lbltxtSombra.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtSombra.Location = new Point(235, 169);
            lbltxtSombra.Name = "lbltxtSombra";
            lbltxtSombra.Size = new Size(67, 20);
            lbltxtSombra.TabIndex = 11;
            lbltxtSombra.Text = "Sombra:";
            // 
            // lbltxtBanosCerca
            // 
            lbltxtBanosCerca.AutoSize = true;
            lbltxtBanosCerca.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtBanosCerca.Location = new Point(235, 32);
            lbltxtBanosCerca.Name = "lbltxtBanosCerca";
            lbltxtBanosCerca.Size = new Size(96, 20);
            lbltxtBanosCerca.TabIndex = 10;
            lbltxtBanosCerca.Text = "Baños cerca:";
            // 
            // lblEntrada
            // 
            lblEntrada.AutoSize = true;
            lblEntrada.Location = new Point(343, 235);
            lblEntrada.Name = "lblEntrada";
            lblEntrada.Size = new Size(31, 20);
            lblEntrada.TabIndex = 24;
            lblEntrada.Text = "NO";
            // 
            // lblZonaTranquila
            // 
            lblZonaTranquila.AutoSize = true;
            lblZonaTranquila.Location = new Point(350, 309);
            lblZonaTranquila.Name = "lblZonaTranquila";
            lblZonaTranquila.Size = new Size(31, 20);
            lblZonaTranquila.TabIndex = 23;
            lblZonaTranquila.Text = "NO";
            // 
            // lblVistas
            // 
            lblVistas.AutoSize = true;
            lblVistas.Location = new Point(291, 94);
            lblVistas.Name = "lblVistas";
            lblVistas.Size = new Size(31, 20);
            lblVistas.TabIndex = 22;
            lblVistas.Text = "NO";
            // 
            // lblSombra
            // 
            lblSombra.AutoSize = true;
            lblSombra.Location = new Point(305, 169);
            lblSombra.Name = "lblSombra";
            lblSombra.Size = new Size(31, 20);
            lblSombra.TabIndex = 21;
            lblSombra.Text = "NO";
            // 
            // lblBanosCerca
            // 
            lblBanosCerca.AutoSize = true;
            lblBanosCerca.Location = new Point(332, 32);
            lblBanosCerca.Name = "lblBanosCerca";
            lblBanosCerca.Size = new Size(31, 20);
            lblBanosCerca.TabIndex = 20;
            lblBanosCerca.Text = "NO";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(76, 235);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(25, 20);
            lblPrecio.TabIndex = 19;
            lblPrecio.Text = "35";
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(64, 94);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(68, 20);
            lblTipo.TabIndex = 17;
            lblTipo.Text = "GRANDE";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(80, 169);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(128, 20);
            lblEstado.TabIndex = 16;
            lblEstado.Text = "MANTENIMIENTO";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(86, 32);
            lblId.Name = "lblId";
            lblId.Size = new Size(17, 20);
            lblId.TabIndex = 15;
            lblId.Text = "1";
            // 
            // ucParcelaDatos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblEntrada);
            Controls.Add(lblZonaTranquila);
            Controls.Add(lblVistas);
            Controls.Add(lblSombra);
            Controls.Add(lblBanosCerca);
            Controls.Add(lblPrecio);
            Controls.Add(lblTipo);
            Controls.Add(lblEstado);
            Controls.Add(lblId);
            Controls.Add(lbltxtEntrada);
            Controls.Add(lbltxtZonaTranquila);
            Controls.Add(lbltxtVistas);
            Controls.Add(lbltxtSombra);
            Controls.Add(lbltxtBanosCerca);
            Controls.Add(lbltxtPrecio);
            Controls.Add(lbltxtTipo);
            Controls.Add(lbltxtEstado);
            Controls.Add(lbltxtId);
            Name = "ucParcelaDatos";
            Size = new Size(400, 366);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltxtId;
        private Label lbltxtEstado;
        private Label lbltxtTipo;
        private Label lbltxtPrecio;
        private Label lbltxtEntrada;
        private Label lbltxtZonaTranquila;
        private Label lbltxtVistas;
        private Label lbltxtSombra;
        private Label lbltxtBanosCerca;
        private Label lblEntrada;
        private Label lblZonaTranquila;
        private Label lblVistas;
        private Label lblSombra;
        private Label lblBanosCerca;
        private Label lblPrecio;
        private Label lblTipo;
        private Label lblEstado;
        private Label lblId;
    }
}
