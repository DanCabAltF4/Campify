﻿namespace Controles
{
    partial class ucEmpleadoDatos
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lbltxtId = new Label();
            lbltxtNombre = new Label();
            lbltxtApellidos = new Label();
            lbltxtDni = new Label();
            lbltxtPuesto = new Label();
            lbltxtTelefono = new Label();
            lbltxtActivo = new Label();
            lblNombre = new Label();
            lblApellidos = new Label();
            lblPuesto = new Label();
            lblDni = new Label();
            lblTelefono = new Label();
            lblActivo = new Label();
            lblId = new Label();
            SuspendLayout();
            // 
            // lbltxtId
            // 
            lbltxtId.AutoSize = true;
            lbltxtId.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtId.Location = new Point(53, 10);
            lbltxtId.Name = "lbltxtId";
            lbltxtId.Size = new Size(32, 20);
            lbltxtId.TabIndex = 0;
            lbltxtId.Text = "Nº:";
            // 
            // lbltxtNombre
            // 
            lbltxtNombre.AutoSize = true;
            lbltxtNombre.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtNombre.Location = new Point(55, 64);
            lbltxtNombre.Name = "lbltxtNombre";
            lbltxtNombre.Size = new Size(71, 20);
            lbltxtNombre.TabIndex = 1;
            lbltxtNombre.Text = "Nombre:";
            // 
            // lbltxtApellidos
            // 
            lbltxtApellidos.AutoSize = true;
            lbltxtApellidos.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtApellidos.Location = new Point(55, 125);
            lbltxtApellidos.Name = "lbltxtApellidos";
            lbltxtApellidos.Size = new Size(78, 20);
            lbltxtApellidos.TabIndex = 2;
            lbltxtApellidos.Text = "Apellidos:";
            // 
            // lbltxtDni
            // 
            lbltxtDni.AutoSize = true;
            lbltxtDni.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtDni.Location = new Point(55, 237);
            lbltxtDni.Name = "lbltxtDni";
            lbltxtDni.Size = new Size(41, 20);
            lbltxtDni.TabIndex = 3;
            lbltxtDni.Text = "DNI:";
            // 
            // lbltxtPuesto
            // 
            lbltxtPuesto.AutoSize = true;
            lbltxtPuesto.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtPuesto.Location = new Point(55, 181);
            lbltxtPuesto.Name = "lbltxtPuesto";
            lbltxtPuesto.Size = new Size(61, 20);
            lbltxtPuesto.TabIndex = 4;
            lbltxtPuesto.Text = "Puesto:";
            // 
            // lbltxtTelefono
            // 
            lbltxtTelefono.AutoSize = true;
            lbltxtTelefono.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtTelefono.Location = new Point(55, 298);
            lbltxtTelefono.Name = "lbltxtTelefono";
            lbltxtTelefono.Size = new Size(33, 20);
            lbltxtTelefono.TabIndex = 5;
            lbltxtTelefono.Text = "Tlf:";
            // 
            // lbltxtActivo
            // 
            lbltxtActivo.AutoSize = true;
            lbltxtActivo.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lbltxtActivo.Location = new Point(55, 354);
            lbltxtActivo.Name = "lbltxtActivo";
            lbltxtActivo.Size = new Size(58, 20);
            lbltxtActivo.TabIndex = 6;
            lbltxtActivo.Text = "Activo:";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(148, 64);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(91, 20);
            lblNombre.TabIndex = 7;
            lblNombre.Text = "Jose Alberto";
            // 
            // lblApellidos
            // 
            lblApellidos.AutoSize = true;
            lblApellidos.Location = new Point(156, 125);
            lblApellidos.Name = "lblApellidos";
            lblApellidos.Size = new Size(123, 20);
            lblApellidos.TabIndex = 8;
            lblApellidos.Text = "Alvarez Gonzalez";
            // 
            // lblPuesto
            // 
            lblPuesto.AutoSize = true;
            lblPuesto.Location = new Point(130, 181);
            lblPuesto.Name = "lblPuesto";
            lblPuesto.Size = new Size(128, 20);
            lblPuesto.TabIndex = 9;
            lblPuesto.Text = "ADMINISTRADOR";
            // 
            // lblDni
            // 
            lblDni.AutoSize = true;
            lblDni.Location = new Point(119, 237);
            lblDni.Name = "lblDni";
            lblDni.Size = new Size(78, 20);
            lblDni.TabIndex = 10;
            lblDni.Text = "72151381J";
            // 
            // lblTelefono
            // 
            lblTelefono.AutoSize = true;
            lblTelefono.Location = new Point(110, 298);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(81, 20);
            lblTelefono.TabIndex = 11;
            lblTelefono.Text = "629933423";
            // 
            // lblActivo
            // 
            lblActivo.AutoSize = true;
            lblActivo.Location = new Point(135, 354);
            lblActivo.Name = "lblActivo";
            lblActivo.Size = new Size(31, 20);
            lblActivo.TabIndex = 12;
            lblActivo.Text = "NO";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(88, 10);
            lblId.Name = "lblId";
            lblId.Size = new Size(50, 20);
            lblId.TabIndex = 13;
            lblId.Text = "label7";
            // 
            // ucEmpleadoDatos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lblId);
            Controls.Add(lblActivo);
            Controls.Add(lblTelefono);
            Controls.Add(lblDni);
            Controls.Add(lblPuesto);
            Controls.Add(lblApellidos);
            Controls.Add(lblNombre);
            Controls.Add(lbltxtActivo);
            Controls.Add(lbltxtTelefono);
            Controls.Add(lbltxtPuesto);
            Controls.Add(lbltxtDni);
            Controls.Add(lbltxtApellidos);
            Controls.Add(lbltxtNombre);
            Controls.Add(lbltxtId);
            Name = "ucEmpleadoDatos";
            Size = new Size(425, 438);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltxtId;
        private Label lbltxtNombre;
        private Label lbltxtApellidos;
        private Label lbltxtDni;
        private Label lbltxtPuesto;
        private Label lbltxtTelefono;
        private Label lbltxtActivo;
        private Label lblNombre;
        private Label lblApellidos;
        private Label lblPuesto;
        private Label lblDni;
        private Label lblTelefono;
        private Label lblActivo;
        private Label lblId;
    }
}
